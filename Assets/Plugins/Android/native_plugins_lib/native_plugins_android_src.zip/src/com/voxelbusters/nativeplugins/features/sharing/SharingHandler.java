package com.voxelbusters.nativeplugins.features.sharing;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;

import com.voxelbusters.nativeplugins.NativePluginHelper;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.defines.Keys.Package;
import com.voxelbusters.nativeplugins.defines.UnityDefines;
import com.voxelbusters.nativeplugins.utilities.ApplicationUtility;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.FileUtility;
import com.voxelbusters.nativeplugins.utilities.StringUtility;

public class SharingHandler
{

	public enum eShareCategeories
	{
		UNDEFINED, TEXT,
	};

	// Create singleton instance
	private static SharingHandler	INSTANCE;

	public static SharingHandler getInstance()
	{
		if (INSTANCE == null)
		{
			INSTANCE = new SharingHandler();
		}
		return INSTANCE;
	}

	// Make constructor private for making singleton interface
	private SharingHandler()
	{
	}

	public boolean canSendMail()
	{
		return ApplicationUtility.isIntentAvailable(getContext(), Intent.ACTION_SEND, Keys.Mime.EMAIL, null);
	}

	public boolean canSendSms()
	{
		Intent intent = new Intent(Intent.ACTION_SENDTO);
		intent.setData(Uri.parse(Keys.Intent.SCHEME_SEND_TO));

		return ApplicationUtility.isIntentAvailable(getContext(), intent);
	}

	public boolean canShareOnWhatsApp()
	{
		return ApplicationUtility.isIntentAvailable(getContext(), Intent.ACTION_SEND, Keys.Mime.PLAIN_TEXT, Package.WHATS_APP);
	}

	public void share(String message, String urlString, byte[] imageByteArray, int byteArrayLength, String excludedShareOptionsJson)
	{

		String[] excludedShareOptions = StringUtility.convertJsonStringToStringArray(excludedShareOptionsJson);

		Bundle bundle = new Bundle();
		bundle.putString(Keys.TYPE, "");
		bundle.putString(Keys.MESSAGE, message);
		bundle.putString(Keys.URL, urlString);

		Uri imageUri = FileUtility.createSharingFileUri(getContext(), imageByteArray, byteArrayLength, CommonDefines.SHARING_DIR, System.currentTimeMillis() + ".png");
		if (imageUri != null)
		{
			bundle.putString(Keys.IMAGE_PATH, imageUri.toString());
		}

		bundle.putStringArray(Keys.EXCLUDE_LIST, excludedShareOptions);

		startActivity(bundle);
	}

	public void sendSms(String messageBody, String recipientsList)
	{
		Bundle bundle = new Bundle();
		bundle.putString(Keys.TYPE, Keys.Sharing.SMS);
		bundle.putString(Keys.MESSAGE, messageBody);
		bundle.putString(Keys.RECIPIENT_LIST, recipientsList);
		startActivity(bundle);
	}

	public void startActivity(Bundle bundleInfo)
	{
		Intent intent = new Intent(NativePluginHelper.getCurrentContext(), SharingActivity.class);
		intent.putExtras(bundleInfo);
		NativePluginHelper.startActivityOnUiThread(intent);
	}

	public void sendMail(String subject, String body, boolean isHtmlBody, byte[] attachmentByteArray, int attachmentByteArrayLength, String mimeType, String attachmentFileNameWithExtn, String recipientsJson)
	{
		Bundle bundle = new Bundle();
		bundle.putString(Keys.TYPE, Keys.Sharing.MAIL);

		bundle.putString(Keys.SUBJECT, subject);

		if (StringUtility.isNullOrEmpty(body))
		{
			body = "";
		}
		CharSequence messageBody = body;

		if (isHtmlBody)
		{
			messageBody = Html.fromHtml(body);
		}

		bundle.putCharSequence(Keys.BODY, messageBody);

		if (attachmentByteArrayLength != 0)
		{
			Uri attachmentUri = FileUtility.createSharingFileUri(getContext(), attachmentByteArray, attachmentByteArrayLength, CommonDefines.SHARING_DIR, attachmentFileNameWithExtn);

			if (attachmentUri != null)
			{
				bundle.putString(Keys.ATTACHMENT, attachmentUri.toString());
			}

		}

		String[] recipients = StringUtility.convertJsonStringToStringArray(recipientsJson);

		if (recipients != null)
		{
			bundle.putStringArray(Keys.RECIPIENT_LIST, recipients);
		}

		startActivity(bundle);
	}

	public void shareOnWhatsApp(String message, byte[] imageByteArray, int imageArrayLength)
	{
		Uri imageUri = null;

		if (canShareOnWhatsApp())
		{
			if (imageArrayLength != 0)
			{
				imageUri = FileUtility.createSharingFileUri(getContext(), imageByteArray, imageArrayLength, CommonDefines.SHARING_DIR, System.currentTimeMillis() + ".png");
			}

			//File destinationFile = new File(imagePath);

			Bundle bundle = new Bundle();
			bundle.putString(Keys.TYPE, Keys.Sharing.WHATS_APP);
			bundle.putString(Keys.MESSAGE, message);
			if (imageUri != null)
			{
				bundle.putString(Keys.IMAGE_PATH, imageUri.toString());
			}

			startActivity(bundle);
		}
		else
		{
			Debug.error(CommonDefines.SHARING_TAG, "Whatsapp unavailable");
			NativePluginHelper.sendMessage(UnityDefines.Sharing.WHATSAPP_SHARE_FINISHED, "" + Keys.Sharing.FAILED);
		}
	}

	Context getContext()
	{
		return NativePluginHelper.getCurrentContext();
	}

}