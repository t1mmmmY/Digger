package com.voxelbusters.nativeplugins.defines;

public class UnityDefines
{
	public static String	NATIVE_BINDING_EVENT_LISTENER	= "NPBinding";

	public class Billing
	{
		public static final String	ON_SETUP_FINISHED			= "";									//TODO
		public static final String	PRODUCTS_REQUEST_SUCCESS	= "RequestForBillingProductsSuccess";
		public static final String	PRODUCTS_REQUEST_FAILED		= "RequestForBillingProductsFailed";
		public static final String	TRANSACTION_FINISHED		= "BillingTransactionFinished";

	}

	public class AddressBook
	{
		public static final String	READ_CONTACTS_FINISED	= "ABReadContactsFinished";
		public static final String	READ_CONTACTS_FAILED	= "ABReadContactsFailed";
	}

	public class MediaLibrary
	{
		public static final String	PICK_IMAGE_FINISHED					= "PickImageFinished";
		public static final String	SAVE_IMAGE_TO_GALLERY_FINISHED		= "SaveImageToGalleryFinished";
		public static final String	PLAY_VIDEO_FROM_GALLERY_FINISHED	= "PickVideoFinished";
		public static final String	PLAY_VIDEO_FINISHED					= "PlayVideoFinished";

	}

	public class Notification
	{
		public static final String	DID_RECEIVE_LOCAL_NOTIFICATION					= "DidReceiveLocalNotification";
		public static final String	DID_REGISTER_FOR_REMOTE_NOTIFICATION			= "DidRegisterRemoteNotification";
		public static final String	DID_FAIL_TO_REGISTER_FOR_REMOTE_NOTIFICATION	= "DidFailToRegisterRemoteNotifications";
		public static final String	DID_RECEIVE_REMOTE_NOTIFICATION					= "DidReceiveRemoteNotification";
	}

	public class Reachability
	{
		//public static final String	NETWORK_CONNECTIVITY_CHANGE	= "ConnectivityChanged";
		public static final String	NETWORK_CONNECTIVITY_HARDWARE_STATUS_CHANGE	= "NetworkHardwareStatusChange";

	}

	public class WebView
	{
		public static final String	WEB_VIEW_DID_SHOW					= "WebViewDidShow";
		public static final String	WEB_VIEW_DID_HIDE					= "WebViewDidHide";
		public static final String	WEB_VIEW_DID_DESTROY				= "WebViewDidDestroy";

		public static final String	WEB_VIEW_DID_START_LOAD				= "WebViewDidStartLoad";
		public static final String	WEB_VIEW_DID_FINISH_LOAD			= "WebViewDidFinishLoad";
		public static final String	WEB_VIEW_DID_FAIL_LOAD_WITH_ERROR	= "WebViewDidFailLoadWithError";

		public static final String	WEB_VIEW_DID_FINISH_EVALUATING_JS	= "WebViewDidFinishEvaluatingJS";
		public static final String	WEB_VIEW_DID_RECEIVE_MESSAGE		= "WebViewDidReceiveMessage";
	}

	public class Twitter
	{
		public static final String	LOGIN_SUCCESS					= "TwitterLoginSuccess";
		public static final String	LOGIN_FAILED					= "TwitterLoginFailed";
		public static final String	COMPOSER_DISMISSED				= "TweetComposerDismissed";
		public static final String	REQUEST_ACCOUNT_DETAILS_SUCCESS	= "RequestAccountDetailsSuccess";
		public static final String	REQUEST_ACCOUNT_DETAILS_FAILED	= "RequestAccountDetailsFailed";
		public static final String	REQUEST_EMAIL_ACCESS_SUCCESS	= "RequestEmailAccessSuccess";
		public static final String	REQUEST_EMAIL_ACCESS_FAILED		= "RequestEmailAccessFailed";
		public static final String	URL_REQUEST_SUCCESS				= "TwitterURLRequestSuccess";
		public static final String	URL_REQUEST_FAILED				= "TwitterURLRequestFailed";
	}

	public class Sharing
	{
		public static final String	SENT_MAIL				= "MailShareFinished";
		public static final String	SENT_SMS				= "MessagingShareFinished";
		public static final String	WHATSAPP_SHARE_FINISHED	= "WhatsAppShareFinished";
		public static final String	FINISHED				= "SharingFinished";

	}

	public class Ui
	{
		public static final String	ALERT_DIALOG_CLOSED					= "AlertDialogClosed";
		public static final String	SINGLE_FIELD_PROMPT_DIALOG_CLOSED	= "SingleFieldPromptDialogClosed";
		public static final String	LOGIN_PROMPT_DIALOG_CLOSED			= "LoginPromptDialogClosed";
	}

}
