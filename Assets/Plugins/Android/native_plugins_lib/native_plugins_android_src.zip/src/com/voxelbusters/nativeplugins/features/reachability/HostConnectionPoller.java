package com.voxelbusters.nativeplugins.features.reachability;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.Callable;

import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.utilities.Debug;

// UNUSED CLASS

public class HostConnectionPoller implements Callable<Void>
{
	//This class has a running task which will pool the host. If any error occurs it notifies the listeners

	private String	host;
	private float	timeGapBetweenPolls;		//In Seconds
	private long	connectionTimeOutPeriod;	//In Seconds
	private int		maxRetryCount;

	private int		currentRetryCount;

	private boolean	isSuspended;

	private boolean	quit	= false;

	HostConnectionPoller()
	{
		host = "http://www.google.com";
		connectionTimeOutPeriod = 60;//60 secs
		maxRetryCount = 3;
		timeGapBetweenPolls = 2.0f;//2 secs gap
	}

	@Override
	public Void call() throws Exception
	{

		//URL 

		URL url = null;
		try
		{
			url = new URL(getHost());
		}
		catch (MalformedURLException e)
		{
			e.printStackTrace();

			Debug.error(CommonDefines.NETWORK_CONNECTIVITY_TAG, "Malformed Url. Taking default one.");
			setHost("http://www.google.com");//set default host value
			url = new URL(getHost());
		}

		try
		{
			while (!quit)
			{
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();

				connection.setRequestMethod("HEAD");

				//Set properties
				connection.setConnectTimeout((int) (getConnectionTimeOutPeriod() * 1000));

				boolean isReachable;
				try
				{
					//Start connection
					connection.connect();

					isReachable = (connection.getResponseCode() == HttpURLConnection.HTTP_OK);
				}
				catch (IOException e)
				{
					isReachable = false;
				}

				if (!isReachable)
				{
					//Inform the delegates that host is not reachable.
					ReportConnectionFailure();
				}
				else
				{
					ReportConnectionSuccess();
				}

				//Sleep for some time between polls
				Thread.sleep((long) (timeGapBetweenPolls * 1000));

				while (isSuspended)
				{
					wait();
				}

			}
		}
		catch (InterruptedException e)
		{
			Debug.warning(CommonDefines.NETWORK_CONNECTIVITY_TAG, "Thread interrupted by stopping the thread");
		}
		return null;
	}

	private void ReportConnectionFailure()
	{
		currentRetryCount++;

		if (currentRetryCount > getMaxRetryCount())
		{

			//NetworkReachabilityHandler.onHostConnectionFailure(getHost());

			//Reset the counter to zero after reporting
			currentRetryCount = 0;
		}
	}

	private void ReportConnectionSuccess()
	{

		//NetworkReachabilityHandler.onHostConnectionSuccess(getHost());
	}

	public String getHost()
	{
		return host;
	}

	public void setHost(String host)
	{
		this.host = host;
	}

	public float getTimeGapBetweenPolls()
	{
		return timeGapBetweenPolls;
	}

	public void setTimeGapBetweenPolls(float timeGapBetweenPolls)
	{
		this.timeGapBetweenPolls = timeGapBetweenPolls;
	}

	public long getConnectionTimeOutPeriod()
	{
		return connectionTimeOutPeriod;
	}

	public void setConnectionTimeOutPeriod(int connectionTimeOutPeriod)
	{
		if (connectionTimeOutPeriod != 0)
		{
			this.connectionTimeOutPeriod = connectionTimeOutPeriod;
		}
		else
		{
			Debug.warning(CommonDefines.NETWORK_CONNECTIVITY_TAG, "time out value should not be zero. Considering default 60 secs for timeout");
		}
	}

	public int getMaxRetryCount()
	{
		return maxRetryCount;
	}

	public void setMaxRetryCount(int maxRetryCount)
	{
		this.maxRetryCount = maxRetryCount;
	}

	public void pause()
	{
		isSuspended = true;
	}

	public void resume()
	{
		isSuspended = false;
	}

	public void quit()
	{
		quit = true;
	}
}
